<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Space Explorer</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

body{
    background:#050816;
    color:white;
    line-height:1.6;
}

header{
    background:linear-gradient(to right,#0f2027,#203a43,#2c5364);
    padding:20px;
    text-align:center;
}

nav{
    margin-top:10px;
}

nav a{
    color:white;
    text-decoration:none;
    margin:0 15px;
    font-weight:bold;
}

.hero{
    text-align:center;
    padding:100px 20px;
    background:url("https://images.unsplash.com/photo-1446776709462-d6b525c57bd3?auto=format&fit=crop&w=1600&q=80") center/cover;
}

.hero h1{
    font-size:60px;
}

.hero p{
    font-size:20px;
    margin:20px 0;
}

button{
    background:#00bfff;
    color:white;
    border:none;
    padding:12px 25px;
    font-size:18px;
    border-radius:8px;
    cursor:pointer;
}

section{
    padding:60px 20px;
    max-width:1000px;
    margin:auto;
}

.cards{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
    justify-content:center;
}

.card{
    background:#111827;
    width:280px;
    padding:20px;
    border-radius:10px;
    text-align:center;
}

.card img{
    width:100%;
    border-radius:10px;
}

footer{
    text-align:center;
    background:#111;
    padding:20px;
    margin-top:40px;
}
</style>
</head>

<body>

<header>
<h1>🚀 Space Explorer</h1>
<nav>
<a href="#about">About</a>
<a href="#planets">Planets</a>
<a href="#gallery">Gallery</a>
</nav>
</header>

<section class="hero">
<h1>Explore the Universe</h1>
<p>Discover planets, stars, galaxies, and the mysteries of space.</p>
<button onclick="showMessage()">Launch Mission</button>
</section>

<section id="about">
<h2>About Space</h2>
<p>
Space is an enormous region beyond Earth's atmosphere filled with stars,
planets, galaxies, black holes, and countless mysteries waiting to be explored.
Scientists continue to study space to better understand our universe.
</p>
</section>

<section id="planets">
<h2>Our Solar System</h2>

<div class="cards">

<div class="card">
<img src="https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&w=600&q=80">
<h3>Earth</h3>
<p>Our home planet and the only known world with life.</p>
</div>

<div class="card">
<img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80">
<h3>Mars</h3>
<p>The Red Planet is a major target for future human exploration.</p>
</div>

<div class="card">
<img src="https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=600&q=80">
<h3>Jupiter</h3>
<p>The largest planet in our Solar System with a giant storm.</p>
</div>

</div>
</section>

<section id="gallery">
<h2>Fun Facts</h2>

<ul>
<li>🌞 The Sun contains over 99% of the Solar System's mass.</li>
<li>🌍 Earth takes 365.25 days to orbit the Sun.</li>
<li>🌌 The Milky Way contains over 100 billion stars.</li>
<li>🚀 Humans first landed on the Moon in 1969.</li>
</ul>

</section>

<footer>
<p>© 2026 Space Explorer | Built with HTML, CSS & JavaScript</p>
</footer>

<script>
function showMessage(){
    alert("🚀 Mission Started! Welcome aboard Space Explorer!");
}
</script>

</body>
</html>